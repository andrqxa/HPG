Телеграм: https://t.me/ponics_ru
Канал: https://www.youtube.com/channel/UCztzK5Azo7YxJQ38IhEe09g
Форум: http://forum.ponics.ru/index.php?topic=2489.msg102234