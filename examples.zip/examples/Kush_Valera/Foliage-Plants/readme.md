### Для пальм, филодендронов и т.д. 

А также чтобы вызвать активный рост.

Telegram: https://t.me/gidroponika_komnatnykh_rasteniy