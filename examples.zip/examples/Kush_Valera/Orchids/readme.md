### Орхидеи не любят высоких ЕС

Telegram: https://t.me/gidroponika_komnatnykh_rasteniy